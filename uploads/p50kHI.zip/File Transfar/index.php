<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Transfer</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="tabs">
            <div class="tab active" data-tab="send">Send</div>
            <div class="tab" data-tab="receive">Receive</div>
        </div>
        <div class="content">
            <div class="tab-content active" id="send">
                <h1>Send File</h1>
                <input type="file" id="file-input">
                <button id="send-btn">Send</button>
                <div class="progress-container">
                    <div class="progress-bar"></div>
                </div>
                <div class="code-container">
                    <span id="generated-code"></span>
                    <button class="copy-btn" id="copy-btn" title="Copy to clipboard"><i class="far fa-copy"></i></button>
                </div>
            </div>
            <div class="tab-content" id="receive">
                <h1>Receive File</h1>
                <input type="text" id="code-input" placeholder="Enter code">
                <button id="receive-btn">Receive</button>
            </div>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>