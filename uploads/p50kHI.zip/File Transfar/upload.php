<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo 'upload_max_filesize: ' . ini_get('upload_max_filesize') . "\n";
echo 'post_max_size: ' . ini_get('post_max_size') . "\n";
echo 'upload_tmp_dir: ' . ini_get('upload_tmp_dir') . "\n";

if (isset($_FILES['file'])) {
    $file = $_FILES['file'];
    $fileName = $file['name'];
    $fileTmpName = $file['tmp_name'];
    $fileSize = $file['size'];
    $fileError = $file['error'];

    // Check for initial upload errors reported by PHP
    if ($fileError !== UPLOAD_ERR_OK) {
        $error_message = 'PHP Upload Error: ';
        switch ($fileError) {
            case UPLOAD_ERR_INI_SIZE:
                $error_message .= 'File is too large (php.ini upload_max_filesize).';
                break;
            case UPLOAD_ERR_FORM_SIZE:
                $error_message .= 'File is too large (HTML form MAX_FILE_SIZE).';
                break;
            case UPLOAD_ERR_PARTIAL:
                $error_message .= 'File was only partially uploaded.';
                break;
            case UPLOAD_ERR_NO_FILE:
                $error_message .= 'No file was uploaded.';
                break;
            case UPLOAD_ERR_NO_TMP_DIR:
                $error_message .= 'Missing a temporary folder.';
                break;
            case UPLOAD_ERR_CANT_WRITE:
                $error_message .= 'Failed to write file to disk.';
                break;
            case UPLOAD_ERR_EXTENSION:
                $error_message .= 'A PHP extension stopped the file upload.';
                break;
            default:
                $error_message .= 'Unknown upload error code: ' . $fileError;
                break;
        }
        echo $error_message;
        exit;
    }

    if ($fileSize < 50000000000) { // 50GB limit
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $code = substr(str_shuffle('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, 6);
        $newFileName = $code . '.' . $fileExt;
        $fileDestination = 'uploads/' . $newFileName;

        // Check if the uploads directory is writable
        if (!is_writable('uploads/')) {
            echo 'Error: Uploads directory is not writable. Permissions: ' . decoct(fileperms('uploads/') & 0777);
        } elseif (!file_exists($fileTmpName)) {
            echo 'Error: Temporary file does not exist: ' . $fileTmpName;
        } elseif (move_uploaded_file($fileTmpName, $fileDestination)) {
            echo $code;
        } else {
            // Get last PHP error for more details
            $lastError = error_get_last();
            echo 'Error moving uploaded file. Details: ' . ($lastError ? $lastError['message'] : 'Unknown error.') . ' Temp file: ' . $fileTmpName . ' Dest: ' . $fileDestination;
        }
    } else {
        echo 'File is too large. Max size is 50GB.';
    }
} else {
    echo 'No file uploaded or invalid request.';
}
?>